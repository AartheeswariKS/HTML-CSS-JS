package com.example.simplecalc;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button add,sub,mul,div;
    EditText a,b;
    TextView res,op1,op2;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        add = (Button) findViewById(R.id.button);
        sub = (Button) findViewById(R.id.button2);
        mul = (Button) findViewById(R.id.button3);
        div = (Button) findViewById(R.id.button4);
        a = (EditText) findViewById(R.id.editTextTextPersonName);
        b = (EditText) findViewById(R.id.editTextTextPersonName2);
        op1=(TextView) findViewById(R.id.textView);
        op2=(TextView) findViewById(R.id.textview2);
        res = (TextView) findViewById(R.id.Result);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double opr1 = Double.parseDouble(a.getText().toString());
                double opr2 = Double.parseDouble(b.getText().toString());
                double ans = opr1 + opr2;
                res.setText(Double.toString(ans));
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double opr1 = Double.parseDouble(a.getText().toString());
                double opr2 = Double.parseDouble(b.getText().toString());
                double ans = opr1 - opr2;
                res.setText(Double.toString(ans));
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double opr1 = Double.parseDouble(a.getText().toString());
                double opr2 = Double.parseDouble(b.getText().toString());
                double ans = opr1 * opr2;
                res.setText(Double.toString(ans));
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double opr1 = Double.parseDouble(a.getText().toString());
                double opr2 = Double.parseDouble(b.getText().toString());
                double ans = opr1 / opr2;
                res.setText(Double.toString(ans));
            }
        });
    }
}